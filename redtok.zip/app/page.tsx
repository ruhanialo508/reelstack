import Feed from "../components/Feed";

export default function Page() {
  return <Feed />;
}