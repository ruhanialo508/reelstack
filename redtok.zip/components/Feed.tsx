'use client';
export default function Feed() {
  return (
    <div style={{height: '100vh', overflowY: 'scroll'}}>
      <p style={{textAlign:'center'}}>🔥 Trending feed will load here</p>
    </div>
  );
}