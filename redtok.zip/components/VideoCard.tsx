export default function VideoCard() {
  return <div>Video</div>;
}